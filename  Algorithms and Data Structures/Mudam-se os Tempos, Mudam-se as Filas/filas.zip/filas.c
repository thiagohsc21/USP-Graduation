#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"

int main(){

    int n;
    scanf("%d", &n);

    fila_t *f1 = create(), *f2 = create(), *f3 = create(), *f4 = create();

    while (n > 0){
        char *comando = recebe_comando();

        if(strcmp(comando, "ENTRA") == 0) add_entrada_na_fila_certa(f1, f2, f3, f4);
        else remove_da_fila_certa(f1, f2, f3, f4);

        free(comando);
        n--;
    }

    liberafila(f1, f2, f3, f4);
    return 0;
}