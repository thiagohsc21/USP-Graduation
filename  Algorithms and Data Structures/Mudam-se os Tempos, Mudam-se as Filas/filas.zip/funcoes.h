#define TamFila 100

typedef struct{
    int idade, csaude;
    char nome[30];
} info_t;

typedef struct{
    int inicio, fim, total;
    info_t pessoas[TamFila];
} fila_t;

void removef(fila_t *f);
int insere(fila_t *f, info_t *p);
int full(fila_t *f);
int empty(fila_t *f);
fila_t *create();
void liberafila(fila_t *f1, fila_t *f2, fila_t *f3, fila_t *f4);
void remove_da_fila_certa(fila_t *f1, fila_t *f2, fila_t *f3, fila_t *f4);
void add_entrada_na_fila_certa(fila_t *f1, fila_t *f2, fila_t *f3, fila_t *f4);
char *recebe_comando();