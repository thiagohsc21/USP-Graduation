#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "funcoes.h"

//----------INICIO DAS FUNCOES REFERENTES A MANUTENÇÃO DA FILA----------
fila_t *create(){
    fila_t *f = (fila_t*) malloc(sizeof(fila_t));
    assert(f != NULL);

    f->inicio = 0;
    f->fim = 0;
    f->total = 0;

    return f;
}

int empty(fila_t *f){
    assert(f != NULL);
    if(f->total == 0) return 1;
    return 0;
}

int full(fila_t *f){
    assert(f != NULL);
    if(f->total == TamFila) return 1;
    return 0;
}

int insere(fila_t *f, info_t *p){
    if(full(f) == 1) return 0;
    assert(p != NULL);

    f->pessoas[f->fim] = *p;
    f->fim = (f->fim+1) % TamFila;
    f->total++;

    return 1;
}

void removef(fila_t *f){
    if(empty(f) == 1) return;

    f->inicio = (f->inicio+1) % TamFila;
    f->total--;
}

void liberafila(fila_t *f1, fila_t *f2, fila_t *f3, fila_t *f4){
    assert(f1 != NULL);
    assert(f2 != NULL);
    assert(f3 != NULL);
    assert(f4 != NULL);

    free(f1);
    free(f2);
    free(f3);
    free(f4);
}
// --------FINAL---------- 

//DE AGORA EM DIANTE SÓ TEM FUNÇÕES QUE TRATAM A ENTRADA E SAÍDA
void add_entrada_na_fila_certa(fila_t *f1, fila_t *f2, fila_t *f3, fila_t *f4){

    info_t *p = (info_t*) malloc(sizeof(info_t));
    scanf("%s %d %d", p->nome, &(p->idade), &(p->csaude));

    if(p->idade >= 60 && p->csaude == 1 && full(f1) != 1) insere(f1,p);
    else if(p->csaude == 1 && full(f2) != 1) insere(f2,p); 
    else if(p->idade >= 60 && full(f3) != 1) insere(f3,p);
    else if(full(f4) != 1) insere(f4,p);
    else printf("FILA CHEIA\n");

    free(p);
}

void remove_da_fila_certa(fila_t *f1, fila_t *f2, fila_t *f3, fila_t *f4){

    if (empty(f1) != 1){
        printf("%s %d %d\n", f1->pessoas[f1->inicio].nome, f1->pessoas[f1->inicio].idade, f1->pessoas[f1->inicio].csaude);
        removef(f1);
    }
    else if (empty(f2) != 1){
        printf("%s %d %d\n", f2->pessoas[f2->inicio].nome, f2->pessoas[f2->inicio].idade, f2->pessoas[f2->inicio].csaude);
        removef(f2);
    }
    else if (empty(f3) != 1){
        printf("%s %d %d\n", f3->pessoas[f3->inicio].nome, f3->pessoas[f3->inicio].idade, f3->pessoas[f3->inicio].csaude);
        removef(f3);
    }
    else if (empty(f4) != 1){
        printf("%s %d %d\n", f4->pessoas[f4->inicio].nome, f4->pessoas[f4->inicio].idade, f4->pessoas[f4->inicio].csaude);
        removef(f4);
    }
    else
        printf("FILA VAZIA\n");
}

char *recebe_comando(){
    char *comando = (char *)malloc(5 * sizeof(char));
    scanf("%s", comando);

    return comando;
}


