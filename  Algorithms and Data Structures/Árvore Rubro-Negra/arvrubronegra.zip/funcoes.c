#include "funcoes.h"

//Cria a arvore.
arvore *cria_arvore(){
    arvore *aux = (arvore*) malloc(sizeof(arvore));
    aux->raiz = NULL;
    return aux;
}

//Faz a inserção de um nó na arvore.
no *insere(arvore *arv, int chave, no *pai, no *atual){
    
    if(atual != NULL){

        if(chave > atual->chave) 
            atual->dir = insere(arv, chave, atual, atual->dir);
        else if(chave < atual->chave) 
            atual->esq = insere(arv, chave, atual, atual->esq);
        
        else atual->chave = chave;
        atual = verifica_cores(arv, atual);
    }
    //Se ele não existe, cria um novo e o retorna para a raiz.
    else{
        
        no *no_auxiliar = (no*) malloc(sizeof(no));
        no_auxiliar->pai = pai;
        no_auxiliar->esq = NULL;
        no_auxiliar->dir = NULL;
        no_auxiliar->cor = red;
    	no_auxiliar->chave = chave;

        return no_auxiliar;
    }

    return atual;
}

//Função responsável por verificar e realizar as rotações para direita/esquerda e também trocar a cor das arestas.
no* verifica_cores(arvore *arv, no *elem){

    no *aux = NULL;

    //Verifica se é necessário realizar uma rotação para esquerda. 
    if((elem->esq != NULL && elem->dir != NULL && elem->esq->cor == black && elem->dir->cor == red) 
    || (elem->esq == NULL && elem->dir != NULL && elem->dir->cor == red)){

        //Se entra nesse if, realiza a rotação, fazendo as trocas necessárias.
        aux = elem->dir;
        elem->dir = aux->esq;

        aux->pai = elem->pai;

        if(aux->esq != NULL) aux->esq->pai = elem;

        if (elem->pai == NULL) arv->raiz = aux;
        else if (elem->pai->dir == elem) elem->pai->dir = aux;
        else if(elem->pai->dir != elem) elem->pai->esq = aux;

        aux->esq = elem; aux->cor = elem->cor;
        elem->pai = aux; elem->cor = red;        

        elem = aux;
    }

    //Verifica se é necessário realizar uma rotação para direita. Se sim, rotaciona.
    if((elem->esq != NULL && elem->esq->esq != NULL) && (elem->esq->cor == red && elem->esq->esq->cor == red)){

        //Se entra nesse if, realiza a rotação, fazendo as trocas necessárias.
        aux = elem->esq;
        elem->esq = aux->dir;

        aux->pai = elem->pai;

        if (aux->dir != NULL) aux->dir->pai = elem;
        
        if (elem->pai == NULL) arv->raiz = aux;
        else if (elem->pai->esq == elem) elem->pai->esq = aux;
        else if(elem->pai->esq != elem) elem->pai->dir = aux;
        
        aux->dir = elem; aux->cor = elem->cor;
        elem->pai = aux; elem->cor = red;

        elem = aux;
    }

    //Verifica se é necessário realizar uma troca nas cores, Se sim, inverte.
    if((elem->esq != NULL && elem->dir != NULL) && (elem->esq->cor == red && elem->dir->cor == red && elem->cor == black)){
       
        elem->cor = red;
        elem->dir->cor = black;
        elem->esq->cor = black;
    }

    return elem;
}

//Função responsável por imprimir o sucessor do elemento o qual possui a "chave" passada
//como parâmetro. Para isso realiza a busca desse elemento e depois o manipula.
void sucessor(int chave, arvore *arv){

    no *atual = busca(chave, arv->raiz);

    if(atual != NULL){
        if (atual->dir == NULL){
            if(atual->pai->dir == atual) 
                while (atual->pai != NULL && atual->pai->esq != atual) atual = atual->pai;     
            
            if(atual->pai != NULL) printf("%d\n", atual->pai->chave);
            else printf("erro\n");        
        } 
        else{
            atual = atual->dir;         
                while (atual->esq != NULL) atual = atual->esq; 
    
            if(atual!= NULL) printf("%d\n", atual->chave);
            else printf("erro\n");
        }
    }

    else printf("erro\n");
}

//Função responsável por imprimir o predecessor do elemento o qual possui a "chave" passada
//como parâmetro. Para isso realiza a busca desse elemento e depois o manipula.
void predecessor(int chave, arvore *arv){

    no *atual = busca(chave, arv->raiz);

    if(atual != NULL){
        if(atual->esq == NULL){
           if(atual->pai->esq == atual)  
                while(atual->pai != NULL && atual->pai->dir != atual) atual = atual->pai;
            
           if(atual->pai != NULL) printf("%d\n", atual->pai->chave);
           else printf("erro\n");
        }
        else{
            atual = atual->esq;
                while(atual->dir != NULL) atual = atual->dir;

            if(atual != NULL) printf("%d\n", atual->chave);
            else printf("erro\n");
        }
    }

    else printf("erro\n");
}

//Busca na arvore pela "chave" passada no parâmetro e retorna o nó que a contém.
no *busca(int chave, no *atual){

    if(atual != NULL){
        if(atual->chave == chave) 
            return atual;
        else{
            if(chave < atual->chave) 
                return busca(chave, atual->esq);
            else
                return busca(chave, atual->dir);
        }
    }
    else return atual;
    
}

void minimo(no *atual){
    if(atual->esq != NULL) minimo(atual->esq);
    else printf("%d\n", atual->chave);
}

void maximo(no *atual){
    if(atual->dir != NULL) maximo(atual->dir);
    else printf("%d\n", atual->chave);
}

//Define o modo de impressao e depois entra na funcao correta. 
void imprime(arvore *arv, int modo){
    if(modo == 6) preordem(arv->raiz);
    else if(modo == 7) ordem(arv->raiz);
    else if(modo == 8) posordem(arv->raiz);
    printf("\n");
}

//Imprime no modo preordem.
void preordem(no *raiz){
    if(raiz != NULL){
        printf("%d ", raiz->chave);
        preordem(raiz->esq);
        preordem(raiz->dir);
    }
}

//Imprime no modo ordem.
void ordem(no *raiz){
    if(raiz != NULL){
        ordem(raiz->esq);
        printf("%d ", raiz->chave);
        ordem(raiz->dir);
    }
}

//Imprime no modo posordem.
void posordem(no *raiz){
    if(raiz != NULL){
        posordem(raiz->esq);
        posordem(raiz->dir);
        printf("%d ", raiz->chave);
    }
}

//Desaloca todos os nós da arvore.
void desaloca_nos(no *not){
    if (not != NULL){
        desaloca_nos(not->esq);
        desaloca_nos(not->dir);
        free(not); 
    }
}

//Desaloca a árvore em si. 
void desaloca_arvore(arvore *arv){
    free(arv);
}