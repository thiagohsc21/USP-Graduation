#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define black 1
#define red 0

typedef struct no_t no;
typedef struct arvore_t arvore;

struct no_t{
    int chave, cor;
    no *esq, *dir, *pai;
};

struct arvore_t{
    no *raiz;
};

//funcoes de manipulacao arvore
arvore *cria_arvore();
no* verifica_cores(arvore *arv, no *elem);
no *insere(arvore *arv, int chave, no *pai, no *atual);
no *busca(int chave, no *atual);
void sucessor(int chave, arvore *arv);
void predecessor(int chave, arvore *arv);
void minimo(no *atual);
void maximo(no *atual);

//funcoes de impressao
void imprime(arvore *arv, int modo);
void preordem(no *raiz);
void ordem(no *raiz);
void posordem(no *raiz);

//funcoes de liberacao de memoria
void desaloca_nos(no *raiz);
void desaloca_arvore(arvore *arv);