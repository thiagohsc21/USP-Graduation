#include "funcoes.h"

int main(){

    arvore *arv = cria_arvore();

    int n;
    scanf("%d", &n);

    while(n > 0){

        int o,x;
        scanf("%d", &o);

        if(o == 1){
            scanf("%d", &x);
            arv->raiz = insere(arv, x, NULL, arv->raiz);
            arv->raiz->cor = black;
        }
        else if(o == 2){
            scanf("%d", &x);
            sucessor(x, arv);
        }
        else if(o == 3){
            scanf("%d", &x);
            predecessor(x, arv);
        }
        else if(o == 4) maximo(arv->raiz);
        else if(o == 5) minimo(arv->raiz);
        else if(o >=6 && o <= 8) imprime(arv, o);

        n--;
    }

    desaloca_nos(arv->raiz);
    desaloca_arvore(arv);
    return 0;
}