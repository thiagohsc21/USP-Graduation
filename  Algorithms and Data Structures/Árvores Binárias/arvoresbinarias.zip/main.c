#include "funcoes.h"

int main(){
    int n, pai, pos = 0;
    scanf("%d",&n);

    arvore *arv = cria_arvore();
    while(n--){
        int id, esq, dir;
        scanf("%d %d %d", &id, &esq, &dir);

        no* p = busca(arv->raiz, id);
        
        if(p == NULL){ 
            insere_esq(arv, -1, id);
            insere_esq(arv, id, esq);
            insere_dir(arv, id, dir);
        } 
        else{
            insere_esq(arv, id, esq);
            insere_dir(arv, id, dir);
        }
        pos++;
    }
    
    imprimir(arv->raiz);
    return 0;
}