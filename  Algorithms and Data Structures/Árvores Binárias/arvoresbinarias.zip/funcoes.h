#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

typedef struct no_t no;
typedef struct arvore_t arvore;
typedef struct info_t informacoes;

struct no_t{
    int id, pai, pos;
    no *esq, *dir;
};

struct arvore_t{
    no *raiz;
};

struct info_t{
    int pos, pai, altura, grau, filhos[2], buscado;
    char tipo[10]; 
};

arvore *cria_arvore();
void insere_esq(arvore *a, int id, int x);
void insere_dir(arvore *a, int id, int x);
int altura(no *raiz);
no *busca(no *raiz, int x);
void imprimir(no *aux);
