#include "funcoes.h"

arvore *cria_arvore(){
    arvore *p = (arvore*) malloc(sizeof(arvore));
    assert(p != NULL);
    no *aux = (no*) malloc(sizeof(no));

    p->raiz = NULL;
    return p;
}

//insere elemento a esquerda do nó atual
void insere_esq(arvore *a, int id, int x){
    no *p = (no*) malloc(sizeof(no));
    p->esq = NULL;
    p->dir = NULL;
    p->id = x;
    p->pai = id;

    //se for -1, é o primeiro nó
    if(id == -1){
        if(a->raiz == NULL) a->raiz = p;
        else free(p);
    }
    else{
        no *aux = busca(a->raiz, id);
        if(aux != NULL && aux->esq == NULL) {
            aux->esq = p;
        }
        else free(p);
    }
}

//insere elemento a esquerda do nó atual
void insere_dir(arvore *a, int id, int x){
    no *p = (no*) malloc(sizeof(no));
    p->esq = NULL;
    p->dir = NULL;
    p->id = x;    
    p->pai = id;

    no *aux = busca(a->raiz, id);
    if(aux != NULL && aux->dir == NULL) {
        aux->dir = p;
    }
    else free(p);
}

//calcula a altura do nó na árvore
int altura(no *raiz){

    if(raiz == NULL) return 0;

    int altura_esquerda = 1 + altura(raiz->esq);
    int altura_direita  = 1 + altura(raiz->dir);

    if(altura_esquerda > altura_direita) return altura_esquerda;
    else return altura_direita;
}

//busca o elemento x na arvore
no *busca(no *raiz, int x){
    if(raiz == NULL) return NULL;
    if(raiz->id == x) return raiz;

    no *p = busca(raiz->esq, x);
    if(p == NULL) p = busca(raiz->dir, x);

    return p;
}

//imprime os elementos 
void imprimir(no *raiz){
    if(raiz != NULL && (raiz->esq != NULL && raiz->dir != NULL)){        
        int filho1 = raiz->esq->id, filho2 = raiz->dir->id, grau;
        char tipo[10];

        if(raiz->id == 0) strcpy(tipo, "raiz");

        if(filho1 == -1 && filho2 == -1){
            grau = 0;
            if(raiz->id != 0) strcpy(tipo, "folha");
        }
        else if((filho1 == -1 && filho2 != -1) || (filho2 == -1 && filho1 != -1)) {
            grau = 1;
            if(raiz->id != 0) strcpy(tipo, "interno"); 
        }
        else {
            grau = 2;
            if(raiz->id != 0) strcpy(tipo, "interno"); 
        }

        printf("no %d: pai = %d, altura = %d, grau = %d, filhos = (%d,%d), tipo = %s\n", raiz->id, raiz->pai, 
        altura(busca(raiz, raiz->id))-1, grau, filho1, filho2, tipo);
    
        imprimir(raiz->esq);
        imprimir(raiz->dir);    
    }
}

