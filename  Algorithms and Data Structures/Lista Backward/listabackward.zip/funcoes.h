typedef struct lista lista_t;
typedef struct no no_t;

lista_t *cria();
void inserir(lista_t *l, int n, int j, int t, int pos);
void remover(lista_t *l, int n);
void busca(lista_t *l, no_t *p, int n);
void decrementa_pos(lista_t *l, no_t *aux);
void imprimir(lista_t *l);
void desaloca(lista_t *l);