#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "funcoes.h"

struct no{
    no_t *prox, *ant;
    int chave, tempo, posicao;
};

struct lista{
    no_t *ini, *fim;
    int tam;
};

lista_t *cria(){

    lista_t *l = NULL;
    l = (lista_t*) malloc(sizeof(lista_t));
    assert (l != NULL);

    l->ini = NULL;
    l->fim = NULL;
    l->tam = 0;

    return l;
}

void inserir(lista_t *l, int n, int j, int t, int pos){

    no_t *p = (no_t*) malloc(sizeof(no_t));
    p->posicao = pos;
    p->tempo = t;
    p->chave = n;

    if(j == 0) p->ant = NULL;

    else{
        int k = (l->tam) - j;
        
        //se k == 0, então queremos referenciar o primeiro elemento
        if(k == 0){
            p->ant = l->ini;
        }
        else{
            no_t *aux = l->ini;
            while(k > 0){
                aux = aux->prox; //vai percorrendo a lista até chegarmos no
                                 //no_t que queremos fazer referência
                k--;
            }
            p->ant = aux;
        }
    }

    if(l->tam == 0){
        l->ini = p;
        l->fim = p;
        p->prox = p;
    }
    else{
        l->fim->prox = p;
        l->fim = p;
    }

    l->tam++;
}

void remover(lista_t *l, int n){

    no_t *aux = l->ini;
    no_t *ref = NULL;
    int v = l->ini->chave;

    //se o elemento estiver no inicio
    if(v == n){
        //se só tiver um elemento na fila
        if(l->tam == 1){
            l->ini = NULL;
            l->fim = NULL;
            l->tam--;
            return;
        }
        else{
            busca(l,aux,n); //quem apontava pro elem, agora aponta pra nulo
            decrementa_pos(l,aux);
            l->ini = l->ini->prox; //o inicio agora é o prox elemento
            l->tam--;
            return;
        }
    }

    //acha o que queremos remover e armazena no aux
    while(v != n){
        ref = aux; //guarda o no_t anterior
        aux = aux->prox;
        v = aux->chave;
    }

    //armazena o tempo (que é uma posicao basicamente) do elemento que será
    //removido, de modo que consigamos verificar se está no final
    int pos = aux->posicao;

    //se o elemento estiver no fim
    if(pos == (l->tam)-1){
        busca(l,aux,n);
        l->fim = ref; //o fim agora é o elemento anterior
        l->fim->prox = NULL;
        l->tam--;
        return;
    }

    //se nao estiver nem no inicio e nem no começo
    else{
        busca(l,aux,n);
        decrementa_pos(l,aux);
        ref->prox = aux->prox; //o elem anterior apontará para o elem seguinte
                               //àquele que será removido
        l->tam--;
        return;
    }
}

//percorre a lista vendo quem aponta pro elemento que será removido
//e então seta com NULL esses ponteiros
void busca(lista_t *l, no_t *p, int n){

    no_t *aux = l->ini;
    //acha quem aponta para o que queremos remover 
    for(int i = 0 ; i < l->tam-1 ; i++){
        aux = aux->prox;
        if(aux->ant == p) aux->ant = NULL;
    }
}

void decrementa_pos(lista_t *l, no_t *aux){

    //enquanto nao chegar no fim decrementa em 1
    //a posicao dos elementos após aquele que foi removido
    while(aux != l->fim){
        aux = aux->prox;
        aux->posicao--;
    }

}

//faz a impressao da maneira como é pedido
void imprimir(lista_t *l){
    assert(l != NULL);

    if(l->tam == 0) printf("-1\n");

    else{
        no_t *p = l->ini;
        for(int i = 0 ; i < l->tam ; i++){
            if(p->ant != NULL) printf("[%d,%d,%d] ", p->chave, p->tempo, p->ant->posicao);
            else printf("[%d,%d] ", p->chave, p->tempo);

            p = p->prox;
        } 
        printf("\n");
    }
}

void desaloca(lista_t *l){
    free(l);
}