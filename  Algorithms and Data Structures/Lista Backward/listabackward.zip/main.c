#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"

int main(){

    lista_t *l = cria();

    char c;
    int tempo = 0, pos = 0, n = 0, j = 0;

    do{
        c = getchar();

        if(c == 'i'){
            scanf("%d %d", &n, &j);
            inserir(l, n, j, tempo, pos);
            tempo++;
            pos++;
        }

        else if(c == 'r'){
            scanf("%d", &n);
            remover(l, n);
            pos--;
            tempo++;
        }

    }while(c != 'f');

    imprimir(l);
    desaloca(l);
    return 0;
}