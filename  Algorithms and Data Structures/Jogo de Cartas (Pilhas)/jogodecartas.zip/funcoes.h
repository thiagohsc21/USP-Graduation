#ifndef test
#define test

typedef struct{
    int elementos[100000];
    int topo;
}pilha_t;

pilha_t *create();
int push(pilha_t *p, int x);
int pop(pilha_t *p, int *x);
int aloca_entrada_na_pilha(pilha_t *compras);
int joga_jogo(pilha_t *compras, pilha_t *descartes, pilha_t *morto, int N);
void destroy(pilha_t *p, pilha_t *q, pilha_t *s);

#endif