#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"

int main(){
    pilha_t *compras = create(), *descartes = create(), *morto = create();
    int N = aloca_entrada_na_pilha(compras);
    int n_rodadas = joga_jogo(compras, descartes, morto, N);
    printf("%d",n_rodadas);

    destroy(compras, descartes, morto);
    return 0;
}