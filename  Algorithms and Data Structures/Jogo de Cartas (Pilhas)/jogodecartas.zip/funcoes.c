#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "funcoes.h"

//cria um ponteiro que aponta para a estrutura da pilha
pilha_t *create(){
    pilha_t *p = (pilha_t*) malloc(sizeof(pilha_t));
    assert(p != NULL);
    p->topo = -1;
    return p;
}

//adiciona o valor x ao topo da nossa pilha
int push(pilha_t *p, int x){
    assert(p != NULL);
    p->topo = p->topo+1;
    p->elementos[p->topo] = x;
    return 1;
}

//remove o valor do topo da nossa pilha e armazena em x por referência
int pop(pilha_t *p, int *x){
    assert(p != NULL);
    *x = p->elementos[p->topo];
    p->topo = p->topo-1;
    return 1;
}

//aloca a entrada passada em um vetor na heap e depois passa para a pilha compra
int aloca_entrada_na_pilha(pilha_t *compras){
    assert(compras != NULL);
    int N,i;
    scanf("%d",&N);

    int *entrada = (int*) malloc(N*sizeof(int));

    for(i = 0; i < N; i++){
		scanf("%d", &entrada[i]);
	}

	for(i = N-1; i >= 0; i--){
		push(compras, entrada[i]);
	}

    free(entrada);
    return N;
}

//funcao que faz a busca dos elementos procurados
int joga_jogo(pilha_t *compras, pilha_t *descartes, pilha_t *morto, int N){
    assert(compras != NULL);
    assert(descartes != NULL);
    assert(morto != NULL);

    int n_procurado = 1, numero_rodadas = 0, x;

    //enquanto numero procurado for menor que a quantidade de numeros
    while(n_procurado <= N){

        //se nao for a primeira rodada, passa todos os numeros da pilha descartes para a pilha compras
        if(numero_rodadas != 0){
            while(descartes->topo != -1){
                pop(descartes, &x);
                push(compras, x);
            }
        }
        
        //enquanto nao tivermos chegado ao final da pilha de compras
        while(compras->topo != -1){

            //se o que estiver no topo for o numero procurado, remove ele da pilha compras e manda para a morto
            if(compras->elementos[compras->topo] == n_procurado){
                pop(compras, &x);
                push(morto, x);
                n_procurado++; //incrementa o numero procurado para dar sequencia na busca
            }

            //se o que estiver no topo nao for o numero procurado, tira da pilha compra e manda pra descartes
            else{
                pop(compras, &x);
                push(descartes, x);
            }
        }

        numero_rodadas++; //incremente o numero de rodadas, pois agora iniciaremos a próxima
    }

    return numero_rodadas;
}

//remove todos os ponteiros que apontam para as pilhas de compra, descarte e morto
void destroy(pilha_t *p, pilha_t *q, pilha_t *s){
    assert(p != NULL);
    free(p);
    p = NULL;

    assert(q != NULL);
    free(q);
    q = NULL;

    assert(s != NULL);
    free(s);
    s = NULL;
}

