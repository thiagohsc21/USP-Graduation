#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"

int main(){
    
    for(int i = 0; i < 3 ; i++){

        int qtd_erros = 0;
        char *frase = Le_Entrada(100);
        char *erro = Le_Entrada(20);
        char *correcao = Le_Entrada(20);
        int  *recebe_posicao_erro = Encontra_Posicao_Erros(frase, erro, &qtd_erros);
        char *frase_corrigida = Gera_Frase_Final(frase, recebe_posicao_erro, correcao, erro, qtd_erros);
        Imprime_Resposta(frase_corrigida);

        Desaloca_Tudo(frase, erro, correcao, recebe_posicao_erro, frase_corrigida, qtd_erros);
    }

    return 0;
}