#ifndef test
#define test

char *Le_Entrada(int tamanho);
int *Encontra_Posicao_Erros(char *frase, char *erro, int *qtd_serros);
char *Gera_Frase_Final(char *frase, int *recebe_posicao_erro, char *correcao, char *erro, int qtd_erros);
void Desaloca_Tudo(char *frase, char *erro, char *correcao, int *recebe_posicao_erro, char *frase_corrigida, int qtd_erros);
void Imprime_Resposta(char *frase_corrigida);

#endif