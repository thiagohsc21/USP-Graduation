#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"

//faz a alocacao dinamica das entradas atribuindo o \0 ao final
char *Le_Entrada(int tamanho){
    char *v = (char*) calloc(tamanho, sizeof(char));
    int i = 0;

    do{
        char aux = fgetc(stdin);
        if(aux != '\r' && !(i == 0 && aux == '\n')) v[i++] = aux;
            
    }while(v[i-1] != '\n' && v[i-1] != EOF);
    v[i-1] = '\0';

    return v;
}

//encontra as posicoes dos erros na frase de entrada, armazena em um vetor na heap e depois retorna
int *Encontra_Posicao_Erros(char *frase, char *erro, int *qtd_erros){
    int *recebe_posicao_erro = NULL, i = 0, j = 0, k = 0, contador = 0, tamanho = 0, guardar_posicao;

    for(i = 0; i < strlen(frase); i++){

        if(erro[j] == frase[i]){ 
            if(contador == 0){ //recebe a posicao inicial do erro dentro da frase 
                guardar_posicao = i; 
            }

            j++;
            contador++;

            //recebe a posicao final do erro dentro da frase e armazena tanto a inicial, quanto a final no vetor
            if(contador == strlen(erro)){ 
                recebe_posicao_erro = (int*) realloc(recebe_posicao_erro,(2+tamanho)*sizeof(int));
                recebe_posicao_erro[tamanho++] = guardar_posicao;
                recebe_posicao_erro[tamanho++] = i;
                (*qtd_erros)++;
            }
        }

        else{
            j = 0;
            contador = 0;
        }
    }
    
    return recebe_posicao_erro;
}

char *Gera_Frase_Final(char *frase, int *recebe_posicao_erro, char *correcao, char *erro, int qtd_erros){
        char *frase_corrigida = (char*) calloc(130, sizeof(char));

        int i = 0, contador = 0;

        //se erros for 0, não há correção a se fazer
        if(qtd_erros == 0){
            free(frase_corrigida);
            frase_corrigida = NULL;
            return frase; 
        }
        
        else{
            while(qtd_erros != 0){

                //quebra por partes a frase, ex:
                // frase: Precisamos corsigir mais um erso
                // strncat: frase_corrigida: Precisamos co
                // strcat: frase_corrigida: Precisamos co + rr
                // strcpy: frase: igir mais de um erso (reduz a frase para a parte que ainda não corrigimos)
                if(i == 0){
                    strncat(frase_corrigida, frase, recebe_posicao_erro[i]);
                    strcat(frase_corrigida, correcao);
                    strcpy(frase, frase+recebe_posicao_erro[i]+strlen(erro));
                    qtd_erros--;
                    i = i + 2;
                }

                //faz a mesma coisa do if, no entanto aqui é um pouco diferente, pois como modificamos a frase
                //se acessarmos o endereço 'frase', ele vai apontar pra i de "igir mais de um erso" e não pra P
                //como no início, então tratei tudo isso, subtraindo a posicao do segundo erro da posicao do primeiro

                // frase: igir mais de um erso
                // strncat: frase_corrigida: Precisamos corr + igir mais de um e
                // strcat: frase_corrigida: Precisamos corrigir mais de um e + rr
                // strcpy: frase: o
                else{
                    strncat(frase_corrigida, frase, recebe_posicao_erro[i]-recebe_posicao_erro[i-2]-strlen(erro));
                    strcat(frase_corrigida, correcao);
                    strcpy(frase, frase+recebe_posicao_erro[i]-recebe_posicao_erro[i-2]);
                    qtd_erros--;
                    i = i + 2;
                }

                //se nao tiverem mais erros e a frase tiver continuação após o ultimo erro
                // strcat: frase_corigida: Precisamos corrigir mais de um err + o
                if(qtd_erros == 0 && strlen(frase) > 0) strcat(frase_corrigida, frase);

            }
        }

    return frase_corrigida;
}

//faz a impressão da resposta
void Imprime_Resposta(char *frase_corrigida){
    for(int i = 0; i < strlen(frase_corrigida); i++){
        printf("%c", frase_corrigida[i]);
        
        if(i == strlen(frase_corrigida) - 1) printf("\n");
    }
}

//libera toda a memória alocada dinamicamente
void Desaloca_Tudo(char *frase, char *erro, char *correcao, int *recebe_posicao_erro, char *frase_corrigida, int qtd_erros){
    free(frase);
    frase = NULL;
    free(erro);
    erro = NULL;
    free(correcao);
    correcao = NULL;
    free(recebe_posicao_erro);
    recebe_posicao_erro = NULL;
    if(qtd_erros != 0){
        free(frase_corrigida);
        frase_corrigida = NULL;
    }
}