#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

typedef struct elo_t elo;
typedef struct lista_t lista;

struct elo_t{
    int num, pos;
    elo *ant, *prox;
};

struct lista_t{
    elo *ini, *fim;
    int tam;
};

char *recebe_numero();
lista *cria_lista();
void cria_elos(lista *p, char *num);
void imprime(lista *l);
int big(lista *l1, lista *l2);
int sml(lista *l1, lista *l2);
int eql(lista *l1, lista *l2);
lista *sum(lista *l1, lista *l2, lista *soma);
void libera_lista(lista *l);

