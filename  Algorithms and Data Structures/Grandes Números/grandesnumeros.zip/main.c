#include "funcoes.h"

int main(){

    int n, res = 1;
    scanf("%d", &n);

    while(n--){
        char operacao[4], c;
        scanf("%s", operacao);
        c = getc(stdin);

        char *n1 = recebe_numero();
        char *n2 = recebe_numero();

        lista *numero1 = cria_lista(), *numero2 = cria_lista();

        cria_elos(numero1, n1);
        cria_elos(numero2, n2);

        if(strcmp(operacao, "sum") == 0){
            lista *soma = cria_lista();
            sum(numero1, numero2, soma);
            printf("Resultado %d: ", res); 
            imprime(soma);
            libera_lista(soma);
        }

        else if(strcmp(operacao, "big") == 0) printf("Resultado %d: %d\n", res, big(numero1, numero2));
        else if(strcmp(operacao, "sml") == 0) printf("Resultado %d: %d\n", res, sml(numero1, numero2));
        else if(strcmp(operacao, "eql") == 0) printf("Resultado %d: %d\n", res, eql(numero1, numero2));

        libera_lista(numero1); 
        libera_lista(numero2);
        res++;
    }

    return 0;
}