#include "funcoes.h"

char *recebe_numero(){
    char *aux = (char*) malloc(sizeof(char)), c = 0;
    int pos = 0;

    while(c != ' ' && c != '\n' && c != '\r' && c != EOF){
        c = getc(stdin);
        aux = realloc(aux, (pos+2)*sizeof(char));
        if(c != ' ' && c != '\n' && c != '\r') aux[pos++] = c;
    }
    aux[pos] = '\0';
    return aux;
}

lista *cria_lista(){
    lista *p = (lista*) malloc(sizeof(lista));
    p->ini = NULL;
    p->fim = NULL;
    p->tam = 0;

    return p;
}

void cria_elos(lista *l, char *num){

    char *aux = (char*) malloc(10*sizeof(char));
    char *aux2 = (char*) malloc(10*sizeof(char));
    int marcador = 0, pos = 1, x = 0, aux3 = strlen(num)/4, flag = 0;

    //calcula quantos numeros diferentes de temos na string num
    while(aux3--) {
        strncpy(aux, num + strlen(num) - (4*pos), 4);
        if(atoi(aux) != 0000) marcador++;
        pos++;
    }
    pos = 1;
    free(aux2);

    //se flag == 1, o numero é negativo
    if(num[0] == '-') flag = 1;
    
    //enquanto o marcador > 0, ainda temos regioes de 4 elementos
    while(marcador > 0 && strlen(num) >=4){

        elo *p = (elo*) malloc(sizeof(elo));
        strncpy(aux, num + strlen(num) - (4*pos) , 4);

        if(flag == 1) p->num = -atoi(aux); //numero que queremos colocar no elo
          
          
        else p->num = atoi(aux);
        p->pos = x; //posicao desse numero na lista

        if(l->tam == 0){
            p->prox = p; //o elemento aponta para ele mesmo
            p->ant = NULL;
            l->fim = p;
            l->ini = p;
        }
        else {
            p->ant = l->fim; //o novo fim recebe como anterior o antigo fim
            l->fim->prox = p; //o antigo fim recebe como próximo o novo fim
            l->fim = p; //o fim agora aponta para p
            l->fim->prox = NULL; //o novo fim agora aponta para nulo
        }
        p = NULL;
        pos++; marcador--; l->tam++; x++;
    }

    //se marcador > 0 quer dizer que existe uma regiao que tem 'marcador' elementos fora da lista
    marcador = strlen(num)%4;
    if(marcador > 0 && strlen(num) > 4){

        char *aux2 = (char*) malloc(5*sizeof(char));
        elo *p = (elo*) malloc(sizeof(elo));
        
        strncpy(aux2, num+strlen(num)-(4*(pos-1))-marcador, marcador);

        if(flag == 1) p->num = -atoi(aux2);
        else p->num = atoi(aux2);
        p->pos = x;
        p->ant = l->fim;
        l->fim->prox = p;
        l->fim = p;
        p->prox = NULL;
        l->tam++;
        p = NULL;
        free(aux2);
    }

    else if(strlen(num) < 4){
        elo *p = (elo*) malloc(sizeof(elo));

        if(flag == 1) p->num = -atoi(num);
        else p->num = atoi(num);
        p->pos = 0;
        p->prox = NULL;
        p->ant = NULL;
        l->ini = p;
        l->tam++;
    }
}

//funcao que veririca se l1 > l2, se sim, retorna 1, se não, retorna 0
int big(lista *l1, lista *l2){

    elo *p1 = l1->ini;
    elo *p2 = l2->ini;

    if(l1->tam > l2->tam) return 1;
    else if(l1->tam < l2->tam) return 0;

    else if(l1->tam == l2->tam){

        int k = l1->tam;
        while(k--){

            if(p1->num > p2->num) return 1;
            else if(p1->num < p2->num) return 0;

            else if(p1->num == p2->num){
                p1 = p1->prox;
                p2 = p2->prox;
            }

        }
    }
}

//funcao que veririca se l1 < l2, se sim, retorna 1, se não, retorna 0
int sml(lista *l1, lista *l2){

    elo *p1 = l1->ini;
    elo *p2 = l2->ini;

    if(l1->tam > l2->tam) return 0;
    else if(l1->tam < l2->tam) return 1;

    else if(l1->tam == l2->tam){

        int k = l1->tam;
        while(k--){

            if(p1->num > p2->num) return 0;
            else if(p1->num < p2->num) return 1;

            else if(p1->num == p2->num){
                p1 = p1->prox;
                p2 = p2->prox;
            }

        }
    }
}

//funcao que veririca se l1 = l2, se sim, retorna 1, se não, retorna 0
int eql(lista *l1, lista *l2){

    elo *p1 = l1->ini;
    elo *p2 = l2->ini;

    if(l1->tam > l2->tam) return 0;
    else if(l1->tam < l2->tam) return 0;

    else if(l1->tam == l2->tam){

        int k = l1->tam;
        while(k--){
            
            if(p1->num > p2->num) return 0;
            else if(p1->num < p2->num) return 0;

            else if(p1->num == p2->num){
                p1 = p1->prox;
                p2 = p2->prox;
            }

        }

        return 1;
    }
}

//funcao que faz a soma de l1 + l2 e armazena em uma lista auxiliar
lista *sum(lista *l1, lista *l2, lista *soma){

    elo *p1 = l1->ini;
    elo *p2 = l2->ini;

    int maior = 0, x = 0;
    if(l1->tam > l2->tam) maior = l1->tam;
    else maior = l2->tam;
    int *sobras  = (int*) malloc((maior+5)*sizeof(int));

    while(maior--){
        elo *p = (elo*) malloc(sizeof(elo));
    
        if(p1 != NULL && p2 != NULL) {
            p->num = (p1->num + p2->num) % 10000;
            sobras[x] = (p1->num + p2->num) / 10000;
        }
        else if(p1 != NULL && p2 == NULL) p->num = p1->num;
        else if(p2 != NULL && p1 == NULL) p->num = p2->num;

        p->pos = x;
        
        if(soma->tam == 0) {
            p->prox = p; //o elemento aponta para ele mesmo
            p->ant = NULL;
            soma->fim = p;
            soma->ini = p;
        } 

        else {

            //se a sobra da soma anterior for diferente de zero, coloca ela na nova soma
            if(sobras[x-1] != 0){
                p->num += sobras[x-1];
                //se a nova soma com a sobra exceder 4 digitos, soma a nova sobra junto a sobra que ja
                //fora calculada quando somamos os numeros contidos na lista 1 e lista 2
                if(p->num / 10000 >= 0) {
                    sobras[x] += p->num/10000;
                    if(p1 != l1->fim && p2 != l2->fim) p->num = p->num % 10000;
                }
            }

            p->ant = soma->fim; //o novo fim recebe como anterior o antigo fim
            soma->fim->prox = p; //o antigo fim recebe como próximo o novo fim
            soma->fim = p; //o fim agora aponta para p
            soma->fim->prox = NULL; //o novo fim agora aponta para nulo
        }
        if(p1 != NULL) p1 = p1->prox;
        if(p2 != NULL) p2 = p2->prox;
        
        p = NULL;
        soma->tam++; x++;
    }

}

//imprime a lista resultante da soma de l1 com l2 
void imprime(lista *l){
    
    int k = l->tam;
    elo *p_aux = l->fim;
    while(k--){
        if(p_aux->num / 1000 == 0 && p_aux != l->fim) printf("%.04d", p_aux->num);
        else printf("%d",p_aux->num);
        p_aux = p_aux->ant;
    }
    printf("\n");
}

//desaloca a memoria usada em cada lista
void libera_lista(lista *l){
    int k = l->tam;
    elo *p_aux = l->ini, *p_ant = NULL;

    while(k--){
        p_ant = p_aux;
        p_aux = p_aux->prox;
        free(p_ant);
    }

    free(l);
}
