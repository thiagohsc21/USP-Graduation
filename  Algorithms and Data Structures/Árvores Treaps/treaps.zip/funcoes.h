#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct no_t no;
typedef struct arvore_t arvore;

struct no_t{
    int chave, prioridade;
    no *esq, *dir;
};

struct arvore_t{
    no *raiz;
};

//funcoes que manipulam a arvore
arvore *cria_arvore();
no* insere(arvore *arv, int chave, int prioridade, no *atual);
no* remover(arvore *arv, int chave, no *atual);
no* balanceamento(no *atual);
no* rotaciona_para_esquerda(no *atual);
no* rotaciona_para_direita(no *atual);
int busca(arvore *arv, int chave);

//funcoes de impressão
void imprime(no *raiz, char *modo);
void largura(no *atual);
void preordem(no *raiz);
void ordem(no *raiz);
void posordem(no *raiz);
int calcula_niveis(no *atual);
void anda_niveis(no *p, int nivel);

//funcoes para desalocar memoria
void desaloca_nos(no *raiz);
void desaloca_arvore(arvore *arv);