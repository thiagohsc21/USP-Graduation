#include "funcoes.h"

int main(){

    arvore *arv = cria_arvore();

    int n;
    scanf("%d", &n);

    while(n > 0){

        char comando[15], modo[15];
        scanf("%s", comando);

        int chave, prioridade;

        if(strcmp(comando, "buscar") == 0){
            scanf("%d", &chave);
            
            int value = busca(arv, chave);
            printf("%d\n", value);
        }

        else if(strcmp(comando, "remocao") == 0){
            scanf("%d %d", &chave, &prioridade);
            arv->raiz = remover(arv, chave, arv->raiz);
        }

        else if(strcmp(comando, "insercao") == 0){
            scanf("%d %d", &chave, &prioridade);
            arv->raiz = insere(arv, chave, prioridade, arv->raiz);
        }

        else if(strcmp(comando, "impressao") == 0){
            scanf("%s", modo);
            imprime(arv->raiz, modo);
        }
        
        n--;
    }

    desaloca_nos(arv->raiz);
    desaloca_arvore(arv);
    return 0;
}
