#include "funcoes.h"

//Cria a arvore.
arvore *cria_arvore(){
    arvore *aux = (arvore*) malloc(sizeof(arvore));
    aux->raiz = NULL;
    return aux;
}

//Realiza a inserção de um novo nó contendo a chave e a prioridade passadas como parâmetro.
no *insere(arvore *arv, int chave, int prioridade, no *atual){

    if(busca(arv, chave) == 1){
        printf("Elemento ja existente\n");
        return atual;
    }

    if(atual == NULL){
        no *no_auxiliar = (no*) malloc(sizeof(no));
        no_auxiliar->esq = NULL;
        no_auxiliar->dir = NULL;
        no_auxiliar->prioridade = prioridade;
    	no_auxiliar->chave = chave;

        return no_auxiliar;
    }

    if(atual->chave > chave) 
        atual->esq = insere(arv, chave, prioridade, atual->esq);
	else 
        atual->dir = insere(arv, chave, prioridade, atual->dir);
    
    return balanceamento(atual);
}

//Busca pela "chave" na arvore, retorna 1 se encontrar e 0 caso contrário. 
int busca(arvore *arv, int chave){
    no *aux = arv->raiz;

    if(aux != NULL){    
        do{ 
            if (aux->chave > chave) aux = aux->esq;  
            else if (aux->chave < chave) aux = aux->dir; 
            else return 1;
        }while (aux != NULL);
    }
    return 0;
}

//Busca o nó o qual possui a chave passada como parametro e o remove.
no* remover(arvore *arv, int chave, no *atual){

    if(busca(arv, chave) == 0){
      printf("Chave nao localizada\n");
      return atual;
    }

    if(atual->chave > chave) 
        atual->esq = remover(arv, chave, atual->esq);

    else if(atual->chave < chave) 
        atual->dir = remover(arv, chave, atual->dir);

    else {
    	if(atual->dir == NULL){
    		no* no_aux = atual->esq;
            free(atual);

            return no_aux;
    	} 
        //Sempre rotacionando para a esquerda como pedido. 
        else{
            atual = rotaciona_para_esquerda(atual);
            atual->esq = remover(arv, chave, atual->esq);
    	}

    	return atual;
    }

    return balanceamento(atual);  
}

//Mantem a arvore balanceada se necessário, sempre que chamada. 
no* balanceamento(no *atual){
    if(atual->esq != NULL && atual->esq->prioridade > atual->prioridade) 
        atual = rotaciona_para_direita(atual);
    if(atual->dir != NULL && atual->dir->prioridade > atual->prioridade) 
        atual = rotaciona_para_esquerda(atual);
        
    return atual;
}

//Rotaciona para a esquerda.
no* rotaciona_para_esquerda(no *atual){
  	no *no_auxiliar = atual->dir;
    atual->dir = no_auxiliar->esq;
    no_auxiliar->esq = atual;

    return no_auxiliar;
}

//Rotaciona para a direita.
no* rotaciona_para_direita(no *atual){
   	no *no_auxiliar = atual->esq;
    atual->esq = no_auxiliar->dir;
    no_auxiliar->dir = atual;

    return no_auxiliar;
}

//Define o modo de impressao e depois entra na funcao correta. 
void imprime(no *raiz, char *modo){
    if(strcmp(modo, "ordem") == 0) ordem(raiz);
    else if(strcmp(modo, "posordem") == 0) posordem(raiz);
    else if(strcmp(modo, "preordem") == 0) preordem(raiz);
    else if(strcmp(modo, "largura") == 0) largura(raiz);
    printf("\n");
}

//Imprime a largura da arvore. Chama as funções auxiliares para calcular
//quantos niveis a árvore tem e imprimir nível por nível.
void largura(no *atual){

    int num_niveis = calcula_niveis(atual);

    int i = 0;
    while(i <= num_niveis){
        anda_niveis(atual, i);
        i++;
    }
    return;
}

//Percorre a árvore adicionando +1 sempre que encontra um novo nível.
int calcula_niveis(no *atual){

    if(atual != NULL) {
        int esq = 0, dir = 0, num;
        dir = calcula_niveis(atual->dir)+1;
        esq = calcula_niveis(atual->esq)+1;

        //Retorna o maior número calculado (representa o nível).
        return num = (esq > dir) ? esq : dir;
    }
    else return 0;
}

//Percore a árvore imprimindo nível por nível.
void anda_niveis(no *atual, int nivel){
    
    if(atual != NULL) {
    
        if(nivel != 1){
            anda_niveis(atual->esq, nivel-1);
            anda_niveis(atual->dir, nivel-1);
        }
        else printf("(%d, %d) ", atual->chave, atual->prioridade);
    }

    else return;
}


//Imprime no modo preordem.
void preordem(no *raiz){
    if(raiz != NULL){
        printf("(%d, %d) ", raiz->chave, raiz->prioridade);
        preordem(raiz->esq);
        preordem(raiz->dir);
    }
}

//Imprime no modo ordem.
void ordem(no *raiz){
    if(raiz != NULL){
        ordem(raiz->esq);
        printf("(%d, %d) ", raiz->chave, raiz->prioridade);
        ordem(raiz->dir);
    }
}

//Imprime no modo posordem.
void posordem(no *raiz){
    if(raiz != NULL){
        posordem(raiz->esq);
        posordem(raiz->dir);
        printf("(%d, %d) ", raiz->chave, raiz->prioridade);
    }
}

//Desaloca todos os nós da arvore.
void desaloca_nos(no *no){
    if (no != NULL){
        desaloca_nos(no->esq);
        desaloca_nos(no->dir);
        free(no); 
    }
}

//Desaloca a árvore em si. 
void desaloca_arvore(arvore *arv){
    free(arv);
}