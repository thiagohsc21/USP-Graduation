#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"

int main(){
    int t, caso = 0;
    scanf("%d", &t);

    while(t > 0){
        int n, k;
        scanf("%d %d", &n, &k);

        lista_t *lista = cria();

        //insere o soldado i na lista
        for(int i = 1 ; i <= n ; i ++) insere(lista, i);

        int sobrevivente = mata_e_retorna_sobrevivente(lista, k);
        printf("Caso %d: %d\n", ++caso, sobrevivente);

        libera(lista);        
        t--;
    }

    return 0;
}