#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "funcoes.h"

struct no{
    int info;
    no_t *prox;
};

struct lista{
    no_t *ini, *fim;
    int tam;
};

lista_t *cria(){
    lista_t *l = (lista_t*) malloc(sizeof(lista_t));
    assert(l != NULL);

    l->ini = NULL;
    l->fim = NULL;
    l->tam = 0;

    return l;
}

void insere(lista_t *l, int i){
    assert(l != NULL);
    no_t *p = (no_t*) malloc(sizeof(no_t));
    p->info = i;

    //lista vazia
    if(l->tam == 0){
        l->fim = p;
        l->ini = p;
        p->prox = p; //o elem aponta pra ele mesmo
    }
    //lista incompleta
    else{
        l->fim->prox = p; //o antigo fim recebe como próximo, o novo fim
        l->fim = p; //muda-se o fim
        p->prox = l->ini; //o novo fim aponta para o inicio

    }

    l->tam++;
}

int mata_e_retorna_sobrevivente(lista_t *l, int k){
    assert(l != NULL);

    no_t *p_morto, *p_ant, *p;
    p_morto = l->ini;

    //mato os soldados até sobrar um
    while(l->tam > 1){
        int i = k;
        
        while(i > 1){

            p_ant = p_morto; //vai guardar o que antes era apontado por p_morto, pois se precisarmos
                             //fazer a troca, ainda teremos o end armazenado

            p_morto = p_morto->prox; //vai percorrendo o círculo até achar o no_t que contem
                                     //o soldado a ser morto
            i--;
        }
        p = p_morto->prox; // guarda a posicao do prox elemento em p

        //se o morto for aquele que está no início
        if(p_morto == l->ini){
            l->fim->prox = l->ini->prox; //o fim agora aponta para o elemento seguinte ao inicio
            l->ini = l->ini->prox; //o inicio agora passa a ser o prox elemento
        }

        //se o morto for aquele que está no fim
        else if(p_morto == l->fim){
            p_ant->prox = l->ini; //posicao anterior ao fim agora aponta para a posicao posterior a ele
            l->fim = p_ant; //o fim agora é a posição anterior
        }

        //caso o morto esteja no meio da lista
        else {
            p_ant->prox = p_morto->prox; //faz a substituiçao do ponteiro para apontar para regiao certa
        }
        free(p_morto);
        p_morto = NULL;

        p_morto = p; //recomeça a contagem a partir do novo soldado guardado em p

        l->tam--;
    }

    return(l->ini->info);
}


void libera(lista_t *l){
    free(l);
}
