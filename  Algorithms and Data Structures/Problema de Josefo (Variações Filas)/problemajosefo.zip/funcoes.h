typedef struct lista lista_t;
typedef struct no no_t;

lista_t *cria();
void desaloca(lista_t *l);
void insere(lista_t *l, int i);
int mata_e_retorna_sobrevivente(lista_t *l, int k);
void libera(lista_t *l);