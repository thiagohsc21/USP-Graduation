#include "funcoes.h"

int main(){
    char nome[25];
    scanf("%s", nome);
    FILE *fp = fopen(nome, "r");

    //numero de linhas que também é o número de músicas
    int n_linhas = quantas_linhas(fp);

    //teremos então n_linhas ponteiros que apontam para structs com as informações pedidas
    info **p = (info**) malloc(n_linhas*sizeof(info*));

    for(int i = 0 ; i < n_linhas ; i++){
        p[i] = (info*) malloc(sizeof(info));
        recebe_entrada(fp, p[i]);
    }
    fclose(fp);

    int num_artistas = 0;
    info_auxiliar **artistas = numero_artistas(p, n_linhas, &num_artistas);

    mergesort_popularidade(artistas, 0, num_artistas-1);

    printf("O Dataset contem %d Artistas e %d Musicas\n", num_artistas, n_linhas);
    printf("Os artistas mais populares sao:\n");
    for(int i = 0 ; i < num_artistas ; i++){
        printf("(%d) Artista: %s, Musicas: %d musicas, Popularidade: %.2lf, Link: https://open.spotify.com/artist/%s\n",
        i+1, artistas[i]->nome_artista, artistas[i]->num_musicas, artistas[i]->popularidade, artistas[i]->id);
    }

    desaloca(p, artistas, n_linhas, num_artistas);
    return 0;
}