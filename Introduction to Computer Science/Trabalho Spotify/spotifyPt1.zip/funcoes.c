#include "funcoes.h"

//função que retorna o número de linhas do arquivo
int quantas_linhas(FILE *fp){
    char c = 0;
    while(c != '\n') c = fgetc(fp); //pula a primeira linha 

    int n_linhas = 0;
    while(!feof(fp)){
        c = fgetc(fp);
        if(c == '\n') n_linhas++;
    }

    fseek(fp, 0, SEEK_SET); //volta para o inicio do arquivo
    return n_linhas;
}

char *readline(FILE *fp){
    char c = 0;
    int pos = 0;
    char *aux = (char*) malloc(sizeof(char));

    //recebe os caracteres e vai colocando na regiao apontada pelo ponteiro aux
    while(c != ';' && c != '\n' && !feof(fp)){
        c = fgetc(fp);
        aux = realloc(aux, (pos+2)*sizeof(char));
        if((pos == 0 && c != ' ') || pos != 0) aux[pos++] = c;
    }
    aux[--pos] = '\0';

    return aux;
}

//funcao que recebe a entrada e armazena numa struct
void recebe_entrada(FILE *fp, info *p){
    char c = 0;
    while(c != '\n') c = fgetc(fp); //pula a primeira linha 
    for(int i = 0 ; i < 18 ; i++) p->infos[i] = readline(fp);
}

//armazena em uma matriz auxiliar o valor da popularidade juntamente com nome e id do artista
info_auxiliar **numero_artistas(info **p, int n_linhas, int *num_artistas){
    int pos = 0, flag = 0;
    info_auxiliar **aux = (info_auxiliar**) malloc(sizeof(info_auxiliar*));

    for(int i = 0 ; i < n_linhas ; i++){
        
        flag = 0; //serve como indicador pra ver se já temos o artista no vetor/ 0 = nao ; 1 = sim

        for(int j = 0 ; j < *num_artistas ; j++){
            //se já tivermos o artista no vetor aux, só somamos a popularidade e incrementamos as musicas
            if(strcmp(p[i]->infos[4], aux[j]->nome_artista) == 0){
                aux[j]->popularidade += atof(p[i]->infos[8]);
                aux[j]->num_musicas++;
                flag = 1;
            }
        }

        //caso nao temos o artista no vetor aux, alocamos memoria pra ele e extraimos seus dados de p[i]
        if(flag == 0){
            aux = (info_auxiliar**) realloc(aux, (*num_artistas+1)*sizeof(info_auxiliar*));
            aux[*num_artistas] = (info_auxiliar*) malloc(sizeof(info_auxiliar));
            aux[*num_artistas]->nome_artista = p[i]->infos[4];
            aux[*num_artistas]->id = p[i]->infos[5];
            aux[*num_artistas]->num_musicas = 1; 
            aux[(*num_artistas)++]->popularidade = atof(p[i]->infos[8]);
        }

    }

    for(int i = 0 ; i < *num_artistas ; i++) aux[i]->popularidade /= aux[i]->num_musicas;
    return aux;
}

//usa o mergesort para ordenar de maneira decrescente os artistas através da popularidade
void mergesort_popularidade(info_auxiliar **p, int ini, int fim){

    if(fim <= ini) return;
    
    int c = (int)((ini+fim)/2.0);
    mergesort_popularidade(p, ini, c);
    mergesort_popularidade(p, c+1, fim);
    
    info_auxiliar **aux = (info_auxiliar**) malloc((fim-ini+1)*sizeof(info_auxiliar*)); 
    int i = ini, j = c+1, k = 0;

    while(i <= c && j <= fim){
        if(p[i]->popularidade >= p[j]->popularidade) aux[k++] = p[i++];
        else aux[k++] = p[j++];
    } 
    
    while(i <= c) aux[k++] = p[i++];
    while(j <= fim) aux[k++] = p[j++];
 
    for(i = ini, k = 0 ; i <= fim ; i++, k++) p[i] = aux[k];
    free(aux);
}

void desaloca(info **p, info_auxiliar **artistas, int n_linhas, int n_artistas){
    for(int i = 0 ; i < n_linhas ; i++) free(p[i]);
    for(int i = 0 ; i < n_artistas ; i++) free(artistas[i]);
    free(p); 
    free(artistas);    
}


