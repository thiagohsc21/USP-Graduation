#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
    char *infos[18];
}info;

typedef struct{
    char *nome_artista, *id;
    int num_musicas;
    double popularidade;
}info_auxiliar;

int quantas_linhas(FILE *fp);
void recebe_entrada(FILE *fp, info *p);
char *readline(FILE *fp);
info_auxiliar **numero_artistas(info **p, int n_linhas, int *n_artistas);
void mergesort_popularidade(info_auxiliar **p, int ini, int fim);
void desaloca(info **p, info_auxiliar **aux, int n_linhas, int n_artistas);