#include "funcoes.h"

int main(){
    char nome[25];
    scanf("%s", nome);
    FILE *fp = fopen(nome, "r");

    int n_musicas = quantas_linhas(fp);

    info **p = (info**) malloc(n_musicas*sizeof(info*));

    for(int i = 0 ; i < n_musicas ; i++){
        p[i] = (info*) malloc(sizeof(info));
        recebe_entrada(fp, p[i]);
    }
    fclose(fp);

    mergesort_id(p, 0, n_musicas-1);

    int x,y;
    scanf("%d %d", &x, &y);

    matriz **mat = (matriz**) malloc(n_musicas*sizeof(matriz*));
    
    for(int i = 0 ; i < n_musicas ; i++)  mat[i] = (matriz*) malloc(n_musicas*sizeof(matriz));

    gera_matriz_dist(mat, p, n_musicas);
    busca_track(x, y, p, mat, n_musicas);

    desaloca_memoria(p, mat, n_musicas);
    return 0;
}