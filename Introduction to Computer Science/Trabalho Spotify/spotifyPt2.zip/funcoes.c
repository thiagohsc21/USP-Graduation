#include "funcoes.h"

//função que retorna o número de linhas do arquivo
int quantas_linhas(FILE *fp){
    char c = 0;
    while(c != '\n') c = fgetc(fp); //pula a primeira linha 

    int n_linhas = 0;
    while(!feof(fp)){
        c = fgetc(fp);
        if(c == '\n') n_linhas++;
    }

    fseek(fp, 0, SEEK_SET); //volta para o inicio do arquivo
    return n_linhas;
}

char *readline(FILE *fp){
    char c = 0;
    int pos = 0;
    char *aux = (char*) malloc(sizeof(char));

    //recebe os caracteres e vai colocando na regiao apontada pelo ponteiro aux
    while(c != ';' && c != '\n' && !feof(fp)){
        c = fgetc(fp);
        aux = realloc(aux, (pos+2)*sizeof(char));
        if((pos == 0 && c != ' ') || pos != 0) aux[pos++] = c;
    }
    aux[--pos] = '\0';

    return aux;
}

//funcao que recebe a entrada e armazena numa struct
void recebe_entrada(FILE *fp, info *p){
    char c = 0;
    while(c != '\n') c = fgetc(fp); //pula a primeira linha 
    for(int i = 0 ; i < 18 ; i++) p->infos[i] = readline(fp);
}

void mergesort_id(info **p, int ini, int fim){

    if(fim <= ini) return;
    
    int c = (int)((ini+fim)/2.0);
    mergesort_id(p, ini, c);
    mergesort_id(p, c+1, fim);
    
    info **aux = (info**) malloc((fim-ini+1)*sizeof(info*)); 
    int i = ini, j = c+1, k = 0;

    while(i <= c && j <= fim){
        if((strcmp(p[i]->infos[1], p[j]->infos[1]) <= 0)) aux[k++] = p[i++];
        else aux[k++] = p[j++];
    } 
    
    while(i <= c) aux[k++] = p[i++];
    while(j <= fim) aux[k++] = p[j++];
 
    for(i = ini, k = 0 ; i <= fim ; i++, k++) p[i] = aux[k];
    free(aux);
}

//funcao que gera a matriz de distancias pedida no problema
void gera_matriz_dist(matriz **m, info **p, int n_musicas){

    for(int i = 0 ; i < n_musicas ; i++){
        for(int j = i+1 ; j < n_musicas ; j++){
            double dist = 0;
            
            //Calcula a distância para cada um dos atributos
            if(i != j) {
                for(int k = 9 ; k < 18 ; k++) dist += pow(atof(p[j]->infos[k])-atof(p[i]->infos[k]),2);
                
                m[i][j].dist = sqrt(dist); m[i][j].ref = j;
                m[j][i].dist = sqrt(dist); m[j][i].ref = i;
            }
            else m[i][i].dist = 0; m[i][i].ref = i;
        }
    }
}

//funcao que realiza a busca binaria da track_id nos dados 
int busca_bin(char *track_id, info **dados, int n_musicas){
    int ini = 0, fim = n_musicas-1, c = 0;

    while(ini <= fim){
        int c = (ini+fim)/2;

        if(strcmp(track_id, dados[c]->infos[1]) < 0) fim = c-1;
        else if((strcmp(track_id, dados[c]->infos[1]) > 0)) ini = c+1;
        else return c;
    }

    return c;
}

//funcao que realiza o a ordenacao da linha através do radix sort (implementada segundo vídeo do prof. moacir)
void radix_sort(matriz **m, int n_musicas, int linha_atual){

    int C[256] = {0}, pos[256];
    matriz *cm = (matriz*) malloc(n_musicas*sizeof(matriz)); 

    for(int shift = 0 ; shift < 64 ; shift += 8){
        for(int i = 0 ; i < n_musicas ; i++){
            short k = (((int)(m[linha_atual][i].dist*1000000)) >> shift ) & 255;
            C[k]++;
            cm[i] = m[linha_atual][i];
        }
        pos[0] = 0;
        for(int j = 1 ; j < 256 ; j++){
            pos[j] = pos[j-1] + C[j-1];
            C[j-1] = 0;
        }
        for(int k = 0 ; k < n_musicas ; k++){
            short p = ((int)(cm[k].dist*1000000) >> shift ) & 255;
            m[linha_atual][pos[p]] = cm[k];
            pos[p]++;
        }
    }

    free(cm);
}

//funcao que realiza as operacoes necessarias com a track_id da entrada, chamando outras funcoes
void busca_track(int x, int y, info **p, matriz **mat, int n_musicas){
    for(int i = 0 ; i < x ; i++){
        char *track_id = (char*) malloc(30*sizeof(char));
        scanf("%s", track_id);

        int pos = busca_bin(track_id, p, n_musicas); 
        radix_sort(mat, n_musicas, pos);
        print_most_similar_tracks(y, mat[pos], pos, p);

        free(track_id);
        track_id = NULL;
    }
}

//faz a impressao da saida da maneira pedida
void print_most_similar_tracks(int K, matriz *m, int linha, info **dados){

    printf("----As %d musicas mais parecidas com %s sao:\n", K, dados[linha]->infos[0]);

    for(int i = 0 ; i < K ; i++){
        printf("\t(%d)Artista: %s\n", i, dados[m[i].ref]->infos[4]);
        printf("\t\tMusica: %s\n", dados[m[i].ref]->infos[0]);
        printf("\t\tDissimilaridade: %lf\n", m[i].dist);
        printf("\t\tLink: https://open.spotify.com/track/%s\n", dados[m[i].ref]->infos[1]);
    }
    printf("\n");
}

//desaloca toda a memoria da heap
void desaloca_memoria(info **dados, matriz **m, int n_musicas){
    for(int i = 0 ; i < n_musicas ; i++) free(dados[i]); 
    free(dados); 
    for(int j = 0 ; j < n_musicas ; j++) free(m[j]);
    free(m);
}