#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

typedef struct{
    char *infos[18];
}info;

typedef struct{
    double dist;
    int ref;
}matriz;

int quantas_linhas(FILE *fp);
void recebe_entrada(FILE *fp, info *p);
char *readline(FILE *fp);
void mergesort_id(info **p, int ini, int fim);
void gera_matriz_dist(matriz **m, info **p, int n_musicas);
int busca_bin(char *track_id, info **dados, int n_musicas);
void radix_sort(matriz **m, int n_musicas, int linha_atual);
void print_most_similar_tracks(int K, matriz *m, int linha, info **dados);
void desaloca_memoria(info **dados, matriz **m, int n_musicas);
void busca_track(int x, int y, info **p, matriz **mat, int n_musicas);