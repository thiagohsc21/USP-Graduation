#include "funcoes.h"

int main(){
    char *livro = (char*) malloc(30*sizeof(char));
    scanf("%s", livro);
    FILE *fp_livro = fopen(livro, "r");
    free(livro);

    skiplist *list = cria_lista();

    //Percorre o livro em questão.
    while(!feof(fp_livro)){
        
        //Recebe as palavras do livro e vai inserindo em uma skiplist.
        char *word = recebe_entrada(fp_livro, 1, 0);
        //if(strcmp(word, "Special") == 0) printf("EXISTE NO LIVRO\n");
        if((word[0] >= 'a' && word[0] <= 'z') || (word[0] >= 'A' && word[0] <= 'Z')) insercao(list, word);
    }

    char *tweets = (char*) malloc(30*sizeof(char));
    scanf("%s", tweets);
    FILE *fp_tweets = fopen(tweets, "r");
    free(tweets);
    
    //Percorre o arquivo .json em questão.
    int marcador = 0;
    while(122333){
        char *word_2 = recebe_entrada(fp_tweets, 2, 0);
        
        //Se acharmos a palavra "text": passamos a receber a frase do tweet.
        if(strcmp(word_2, "\"text\":") == 0){
            marcador = 1;
            int flag = 0;

            //Enquanto não chegamos no final da frase, faz a busca para cada uma das palavras. 
            while(flag != 1){
                char *palavra_tweet = recebe_entrada(fp_tweets, 3, &flag);
                if((palavra_tweet[0] >= 'a' && palavra_tweet[0] <= 'z') || (palavra_tweet[0] >= 'A' && palavra_tweet[0] <= 'Z')){
                    //if(strcmp(palavra_tweet, "Special") == 0) printf("EXISTE NO TWEET\n");
                    no *aux = busca(list, palavra_tweet);
                    if(aux == NULL) printf("%s ", palavra_tweet);
                }
            }

            printf("\n");   
        }

        if(word_2[0] == EOF) {
            if(marcador == 0) printf("No tweets to check\n");
            break;
        }
    }

    return 0;
}