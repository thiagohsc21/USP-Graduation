#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAIORNIVEL 80

typedef struct SKIPLIST skiplist;
typedef struct NO no;

struct SKIPLIST{
    no *upleft;
    int niveis_max;
};

struct NO{
    int nivel; 
    char *palavra;
    no *baixo;
    no *prox;
};

char *recebe_entrada(FILE *fp, int modo, int *flag);
skiplist *cria_lista();
no *cria_no(char *word, int nivel, no *prox, no *baixo);
int sorteia_num();
no *busca(skiplist *dic, char *word);
int insercao(skiplist *dic, char *word);

