#include "funcoes.h"

//Funcao que recebe a entrada.
char *recebe_entrada(FILE *fp, int modo, int *flag){

    char *word = (char*) malloc(1*sizeof(char)), c = 'a';
    int tam = 0;

    if(modo == 1){
        while((c >= 'a' && c <= 'z') || (c >='A' && c <= 'Z')){
            c = getc(fp);
            if(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z') {
                word = (char*) realloc(word, (tam+2)*sizeof(char));
                word[tam++] = c;
            }
        }
    }

    else if(modo == 2){
        while(c != EOF && c != ' ' && c != '\n' && c != '\r'){
            c = getc(fp);
            if(c != ' ' && c != '\n' && c != '\r') {
                word = (char*) realloc(word, (tam+2)*sizeof(char));
                word[tam++] = c;
            }
        } 
    }

    else if(modo == 3){
         while(((c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z')) && (c != EOF && c != '\n' && c != '\r')){
            c = getc(fp);
            if(c == '\n') *flag = 1;
            if(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z') {
                word = (char*) realloc(word, (tam+2)*sizeof(char));
                word[tam++] = c;
            }
        }
    }

    word[tam] = '\0';
    return word;
}

//Todos os 80 níveis serão criados de modo a simplificar o programa. 
//Cada um deles conterá uma flag que possuirá NULL nos campos onde teriam o verbete e sua definição. 
skiplist *cria_lista(){
    skiplist *list = (skiplist*) malloc(sizeof(skiplist));

    no *p = NULL;
    list->niveis_max = MAIORNIVEL;
    int x = 0;

    while(x <= MAIORNIVEL){
        p = cria_no(NULL, x, NULL, p);
        list->upleft = p;
        x++;
    }
}

//Cria um nó com as informações passadas.
no *cria_no(char *word, int nivel, no *prox, no *baixo){
    no *aux = (no*) malloc(sizeof(no));
    aux->nivel = nivel;
    aux->prox = prox;
    aux->baixo = baixo;
    aux->palavra = word;
    return aux;
}

//Gera um número aleatório e vê se ele é divisível por 2, se for, incrementa um contador.
//Retorna esse contador, que equivale a quantidade de níveis de um novo nó.
int sorteia_num(){
    int count = 0, num = rand()%2;
    while(num != 0 && count < MAIORNIVEL){
        num = rand()%2;
        count++;
    }
    return count;
}

//Faz a inserção de um nó na lista. Retorna 0 se falhou e 1 se obteve sucesso.
int insercao(skiplist *dic, char *word){
    //Verifica se a palavra contida no nó elem já está na lista. NULL : Não está.
    if(busca(dic, word) != NULL) return 0;

    no *sentinel = dic->upleft;
    no **vector = (no**) malloc((MAIORNIVEL+5)*sizeof(no*));

    //Busca a posição em que devemos inserir o novo nó em cada um dos niveis (exceto 0).
    while(sentinel->nivel > 0){
        while(sentinel->prox != NULL && strcasecmp(sentinel->prox->palavra, word) < 0) sentinel = sentinel->prox;
        
        //Armazena o nó no indice do vetor que corresponde ao nível em que ele está contido.
        vector[sentinel->nivel] = sentinel;
        //Muda de nível e recomeça.
        sentinel = sentinel->baixo;
    }

    //Busca a posição em que devemos inserir o novo nó no nível 0.
    while(sentinel->prox != NULL && strcasecmp(sentinel->prox->palavra, word) < 0) sentinel = sentinel->prox;
    vector[sentinel->nivel] = sentinel;

    //Sorteia o número de níveis do novo nó o qual está sendo inserido.
    int nivel_do_no = sorteia_num(), nivel_atual = 0;

    //Insere nas posições corretas da lista o nó "elem" passado no parâmetro da função.
    while(nivel_atual <= nivel_do_no){

        //Cria um nó para cada nível.
        no *elem = cria_no(word, nivel_atual, NULL, NULL);

        //Se o nivel atual for diferente de 0, teremos que inserir o nó em outras camadas da lista.
        if(nivel_atual != 0){  
            elem->nivel = nivel_atual;
            elem->prox = vector[nivel_atual]->prox;
            elem->baixo = vector[nivel_atual-1]->prox;
            vector[nivel_atual]->prox = elem;
        }
        //Se o nivel atual for igual a 0, temos que inserir o nó somente nele.
        else{
            elem->nivel = nivel_atual;
            elem->prox = vector[nivel_atual]->prox;
            elem->baixo = NULL;
            vector[nivel_atual]->prox = elem;
        }
        nivel_atual++;
    }
    free(vector); return 1;
}

//Função que realiza a busca da palavra 'word' na lists 'dic'. 
//Retorna NULL em caso de falha e o no que contém a palavra em caso de sucesso.
no *busca(skiplist *dic, char *word){
    no *sentinel = dic->upleft;

    //Busca nos níveis acima do 0. 
    while(sentinel->nivel > 0){                            

        //Verificação horizontal do nível em que estamos
        while(sentinel->prox != NULL && strcasecmp(sentinel->prox->palavra, word) < 0) sentinel = sentinel->prox;

        //Se a palavra em que estamos já é maior que a que buscamos, descemos para o próximo nível.
        sentinel = sentinel->baixo;
    }

    //Busca no nível 0.
    while(sentinel->prox != NULL && strcasecmp(sentinel->prox->palavra, word) < 0) sentinel = sentinel->prox;

    if(sentinel->prox != NULL && strcasecmp(sentinel->prox->palavra, word) == 0) {
        //if(word[0] >= 'A' && word[0] <= 'Z') word[0] += 32;
        return sentinel->prox;
    }
    else return NULL;

}